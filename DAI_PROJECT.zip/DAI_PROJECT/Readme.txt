1. At first download the Dataset (AmazonCat-13K (1M+ instances, 13K labels).
2. Execute the code and for precesion and reults we have used Matlab.
3. Run all the separate files of code one by one .
4. Run the below command for MATLAB execution.

  ./n1_fastXML_predict /home/cclab/DA/Tree_Extreme_Classifiers/FastXML/AmazonCat-13K.bow/test_features.txt                    /home/cclab/DA/Tree_Extreme_Classifiers/FastXML/AmazonCat-13K.bow/test_scores_10trees.txt                    /home/cclab/DA/Tree_Extreme_Classifiers/FastXML/model -T 5 -s 0 -t 10


./n1_fastXML_train /home/cclab/DA/Tree_Extreme_Classifiers/FastXML/AmazonCat-13K.bow/train_features.txt                    /home/cclab/DA/Tree_Extreme_Classifiers/FastXML/AmazonCat-13K.bow/train_labels.txt                    /home/cclab/DA/Tree_Extreme_Classifiers/FastXML/model -T 5 -s 0 -t 10 -b 1.0 -c 1.0 -m 10






